# Uncle Punch

A Unity game project mimicking the game "Annoying Uncle Punch", made using Unity and C#.

## How to Clone

You can clone this repository using **SSH**:

### SSH
```bash
git clone git@github.com:faayeq/uncle_punch.git
```

## How to Open

### Steps
1. Open Unity Hub.
2. Click Open and select the uncle_punch folder.
3. Open the project in Unity(with a relatively newer version of Unity required).
